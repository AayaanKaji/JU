console.log("JavaScript file loaded!");
document.getElementById("header").innerText = "JS source file is loaded!"